#! usr/bin/env Python

from . import AnchorCLI

def main():
    AnchorCLI.main()
